### Hexlet tests and linter status:
[![Actions Status](https://github.com/skaym00t/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/skaym00t/python-project-49/actions)
### Maintainability Badge
[![Maintainability](https://api.codeclimate.com/v1/badges/3899b606838fb62ebede/maintainability)](https://codeclimate.com/github/skaym00t/python-project-49/maintainability)
### Presenattion
[![Install game and brain-even](https://asciinema.org/a/hz1kyfrdZ6ecGbnAbEv8ijRvZ.svg)](https://asciinema.org/a/hz1kyfrdZ6ecGbnAbEv8ijRvZ)
[![brain-calc](https://asciinema.org/a/bCbJYxmFExBpzoSJ1cqd4ZHPZ.svg)](https://asciinema.org/a/bCbJYxmFExBpzoSJ1cqd4ZHPZ)
[![brain-gcd](https://asciinema.org/a/3qfFnINTZ5iKKSnTQ0O0GlQkZ.svg)](https://asciinema.org/a/3qfFnINTZ5iKKSnTQ0O0GlQkZ)
[![brain-progression](https://asciinema.org/a/vqmI8sDwKHQJodeX89cjsQX3w.svg)](https://asciinema.org/a/vqmI8sDwKHQJodeX89cjsQX3w)
[![brain-prime](https://asciinema.org/a/jjg5NHwWfgQAZDjD3MKJ14jey.svg)](https://asciinema.org/a/jjg5NHwWfgQAZDjD3MKJ14jey)